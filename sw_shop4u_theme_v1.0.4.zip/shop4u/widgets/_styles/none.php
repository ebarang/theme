<?php
/**
 * Widget Style: xHtml
 *
 */

$ws['none'] = array(
	'before_widget' => '',
	'after_widget' => '',
	'before_title' => '',
	'after_title' => ''
);