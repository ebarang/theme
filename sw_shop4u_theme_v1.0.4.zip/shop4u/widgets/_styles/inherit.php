<?php
/**
 * Widget Style: Inherit
 *
 */
$ws['inherit'] = null;