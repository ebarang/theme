<?php
/**
 * Widget Style: Widget Language Home10
 *
 */

$ws['language-home10'] = array(
	'before_title' => '<h3>',
	'after_title' => '</h3>',
	'before_widget' => '<div class="widget %1$s %2$s language-home10"><div class="widget-inner">',
	'after_widget' => '</div></div>',
);