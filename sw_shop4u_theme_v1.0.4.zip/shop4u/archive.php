<?php
	shop4u_blog_listing_check();
?>