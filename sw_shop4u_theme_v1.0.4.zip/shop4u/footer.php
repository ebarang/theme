<?php shop4u_footer_check(); ?>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>