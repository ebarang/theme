<?php
$less_variables = array(
	'color'        => '#cb2d41',
	'a-color'      => '#cb2d41',
	'body-color'   => '#222222',
	'border-color' => '#eeeeee',
	'url'     => "'../assets/img/pink'",
);

