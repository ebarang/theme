<?php
$less_variables = array(
	'color'        => '#ed1c24',
	'a-color'      => '#ed1c24',
	'body-color'   => '#222222',
	'border-color' => '#eeeeee',
	'url'     => "'../assets/img/default'",
);

