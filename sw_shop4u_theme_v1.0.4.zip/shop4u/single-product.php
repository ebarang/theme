<?php
/**
 * Single Product
 * @version 9.9.9
 */
?>

<?php shop4u_product_detail_check(); ?>